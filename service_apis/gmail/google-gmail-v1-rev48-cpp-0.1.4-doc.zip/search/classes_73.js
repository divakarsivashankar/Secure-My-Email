var searchData=
[
  ['scopes',['SCOPES',['../classgoogle__gmail__api_1_1GmailService_1_1SCOPES.html',1,'google_gmail_api::GmailService']]],
  ['sendas',['SendAs',['../classgoogle__gmail__api_1_1SendAs.html',1,'google_gmail_api']]],
  ['sendasresource',['SendAsResource',['../classgoogle__gmail__api_1_1GmailService_1_1UsersResource_1_1SettingsResource_1_1SendAsResource.html',1,'google_gmail_api::GmailService::UsersResource::SettingsResource']]],
  ['settingsresource',['SettingsResource',['../classgoogle__gmail__api_1_1GmailService_1_1UsersResource_1_1SettingsResource.html',1,'google_gmail_api::GmailService::UsersResource']]],
  ['smtpmsa',['SmtpMsa',['../classgoogle__gmail__api_1_1SmtpMsa.html',1,'google_gmail_api']]]
];
