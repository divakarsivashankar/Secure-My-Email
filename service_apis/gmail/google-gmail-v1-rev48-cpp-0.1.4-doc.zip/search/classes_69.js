var searchData=
[
  ['imapsettings',['ImapSettings',['../classgoogle__gmail__api_1_1ImapSettings.html',1,'google_gmail_api']]]
];
