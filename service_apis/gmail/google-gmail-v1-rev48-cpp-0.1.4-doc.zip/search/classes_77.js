var searchData=
[
  ['watchrequest',['WatchRequest',['../classgoogle__gmail__api_1_1WatchRequest.html',1,'google_gmail_api']]],
  ['watchresponse',['WatchResponse',['../classgoogle__gmail__api_1_1WatchResponse.html',1,'google_gmail_api']]]
];
