var searchData=
[
  ['gmailservice',['GmailService',['../classgoogle__gmail__api_1_1GmailService.html',1,'google_gmail_api']]],
  ['gmailservicebaserequest',['GmailServiceBaseRequest',['../classgoogle__gmail__api_1_1GmailServiceBaseRequest.html',1,'google_gmail_api']]]
];
