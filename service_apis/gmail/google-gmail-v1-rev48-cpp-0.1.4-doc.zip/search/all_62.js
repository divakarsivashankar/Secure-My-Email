var searchData=
[
  ['batchdeletemessagesrequest',['BatchDeleteMessagesRequest',['../classgoogle__gmail__api_1_1BatchDeleteMessagesRequest.html',1,'google_gmail_api']]],
  ['batchdeletemessagesrequest',['BatchDeleteMessagesRequest',['../classgoogle__gmail__api_1_1BatchDeleteMessagesRequest.html#a397eea2b6ac5833d7fdff5fbe9f9f698',1,'google_gmail_api::BatchDeleteMessagesRequest::BatchDeleteMessagesRequest(const Json::Value &amp;storage)'],['../classgoogle__gmail__api_1_1BatchDeleteMessagesRequest.html#a40ce7d8a236fc6073b32dbe7067aa04e',1,'google_gmail_api::BatchDeleteMessagesRequest::BatchDeleteMessagesRequest(Json::Value *storage)']]]
];
