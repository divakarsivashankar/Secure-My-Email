var searchData=
[
  ['draft',['Draft',['../classgoogle__gmail__api_1_1Draft.html#a7efcb68499202b36440d8266b8d65432',1,'google_gmail_api::Draft::Draft(const Json::Value &amp;storage)'],['../classgoogle__gmail__api_1_1Draft.html#a8fd4975d8cd6725c27a557a34e7cc671',1,'google_gmail_api::Draft::Draft(Json::Value *storage)']]],
  ['draftsresource',['DraftsResource',['../classgoogle__gmail__api_1_1GmailService_1_1UsersResource_1_1DraftsResource.html#ad104d61e758134c52504356a8ef7aed3',1,'google_gmail_api::GmailService::UsersResource::DraftsResource']]]
];
