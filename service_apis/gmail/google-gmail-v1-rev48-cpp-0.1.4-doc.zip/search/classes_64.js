var searchData=
[
  ['draft',['Draft',['../classgoogle__gmail__api_1_1Draft.html',1,'google_gmail_api']]],
  ['draftsresource',['DraftsResource',['../classgoogle__gmail__api_1_1GmailService_1_1UsersResource_1_1DraftsResource.html',1,'google_gmail_api::GmailService::UsersResource']]]
];
