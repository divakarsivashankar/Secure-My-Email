var searchData=
[
  ['mail_5fgoogle_5fcom',['MAIL_GOOGLE_COM',['../classgoogle__gmail__api_1_1GmailService_1_1SCOPES.html#a042ad5fca8a771c9ee623f6248d34dad',1,'google_gmail_api::GmailService::SCOPES']]]
];
