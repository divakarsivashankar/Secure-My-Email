var searchData=
[
  ['imapsettings',['ImapSettings',['../classgoogle__gmail__api_1_1ImapSettings.html',1,'google_gmail_api']]],
  ['imapsettings',['ImapSettings',['../classgoogle__gmail__api_1_1ImapSettings.html#a1e2b671a3de25c571611c5fad8095f93',1,'google_gmail_api::ImapSettings::ImapSettings(const Json::Value &amp;storage)'],['../classgoogle__gmail__api_1_1ImapSettings.html#abac512d0d374c5286ea069c0ab6b0e8c',1,'google_gmail_api::ImapSettings::ImapSettings(Json::Value *storage)']]]
];
