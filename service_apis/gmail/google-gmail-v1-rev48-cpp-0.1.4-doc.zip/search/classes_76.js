var searchData=
[
  ['vacationsettings',['VacationSettings',['../classgoogle__gmail__api_1_1VacationSettings.html',1,'google_gmail_api']]]
];
