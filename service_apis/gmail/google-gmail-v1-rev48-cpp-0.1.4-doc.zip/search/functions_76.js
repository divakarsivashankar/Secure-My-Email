var searchData=
[
  ['vacationsettings',['VacationSettings',['../classgoogle__gmail__api_1_1VacationSettings.html#a2290083e19b304fe8c65fb186996f670',1,'google_gmail_api::VacationSettings::VacationSettings(const Json::Value &amp;storage)'],['../classgoogle__gmail__api_1_1VacationSettings.html#aefc69cf216d9923ee97b391fca9ae50f',1,'google_gmail_api::VacationSettings::VacationSettings(Json::Value *storage)']]]
];
