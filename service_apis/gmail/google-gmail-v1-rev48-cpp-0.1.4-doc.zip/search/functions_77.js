var searchData=
[
  ['watchrequest',['WatchRequest',['../classgoogle__gmail__api_1_1WatchRequest.html#a0c5b30031b2f40534508debbad8413d7',1,'google_gmail_api::WatchRequest::WatchRequest(const Json::Value &amp;storage)'],['../classgoogle__gmail__api_1_1WatchRequest.html#a0a3bf0e4de00f868db54dfbf60159308',1,'google_gmail_api::WatchRequest::WatchRequest(Json::Value *storage)']]],
  ['watchresponse',['WatchResponse',['../classgoogle__gmail__api_1_1WatchResponse.html#a58c93481a16ec48fd60e57a278739fb6',1,'google_gmail_api::WatchResponse::WatchResponse(const Json::Value &amp;storage)'],['../classgoogle__gmail__api_1_1WatchResponse.html#ab9d381ebc249d105eeeb3ced9e012ef6',1,'google_gmail_api::WatchResponse::WatchResponse(Json::Value *storage)']]]
];
