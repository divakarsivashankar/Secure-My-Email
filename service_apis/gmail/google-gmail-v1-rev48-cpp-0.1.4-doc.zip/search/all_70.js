var searchData=
[
  ['popsettings',['PopSettings',['../classgoogle__gmail__api_1_1PopSettings.html',1,'google_gmail_api']]],
  ['popsettings',['PopSettings',['../classgoogle__gmail__api_1_1PopSettings.html#a73b060140517e63773e98e15de9e1b33',1,'google_gmail_api::PopSettings::PopSettings(const Json::Value &amp;storage)'],['../classgoogle__gmail__api_1_1PopSettings.html#ac1e1f13ca3047d616c4a5006259c3b01',1,'google_gmail_api::PopSettings::PopSettings(Json::Value *storage)']]],
  ['profile',['Profile',['../classgoogle__gmail__api_1_1Profile.html#a3313b5fafe02c1aa81d6263c153d6d53',1,'google_gmail_api::Profile::Profile(const Json::Value &amp;storage)'],['../classgoogle__gmail__api_1_1Profile.html#a5a0110a224fa26faeef50f0c340413e9',1,'google_gmail_api::Profile::Profile(Json::Value *storage)']]],
  ['profile',['Profile',['../classgoogle__gmail__api_1_1Profile.html',1,'google_gmail_api']]]
];
